<div <?php print $attributes;?> class="<?php print $classes;?>">
  <div class="mega-dropdown-inner">
    <?php print $rows;?>
  </div>
</div>
